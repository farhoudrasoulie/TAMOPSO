Software Requirements, Dependencies, and Execution Environment

Successful execution and reproduction of the simulations in this project require an appropriately configured MATLAB environment and the installation of all necessary software components, libraries, and dependencies. The code was developed and configured for execution using MATLAB R2024b under Windows 11. Before running the project, users should ensure that a compatible MATLAB installation is available, all required MATLAB toolboxes and any external functions or third-party libraries referenced by the source code are installed and accessible, and all supplementary MATLAB scripts, function files, input datasets, terrain models, and configuration files are located in their designated directories and included in the MATLAB search path. Adequate computational resources, including sufficient RAM, processing capacity, and disk space, are also necessary, particularly when performing multiple independent simulation runs with large populations and high iteration limits. Furthermore, the simulation parameters, algorithm configurations, objective-function definitions, and random-number-generation settings should be checked and configured appropriately before execution. Differences in MATLAB versions, operating systems, toolbox releases, or dependency configurations may affect compatibility, computational performance, and numerical results. Therefore, users are strongly advised to verify all prerequisites, dependency versions, folder structures, and configuration settings before initiating the simulations. Full and successful execution of the project, as well as the reproducibility and consistency of its computational results, depends on satisfying these software, hardware, and configuration requirements.


TAMOPSO TABLE 10 RUN-READY PACKAGE
=================================

START HERE
----------
1. Extract the entire ZIP file to a normal writable folder.
2. Open MATLAB and set the Current Folder to the extracted folder
   (the folder containing TOMOPSO_MAIN.m).
3. In the MATLAB Command Window, type exactly:

       TOMOPSO_MAIN

4. Press Enter. The script runs the four configurations and saves the output
   under Table10_Verification_Results/Verification_YYYYMMDD_HHMMSS/.

Do not move individual .m files into different folders. All active MATLAB
files are together in the top-level package folder. The original uploaded
source is kept separately in original_uploaded_source/ and is NOT added to
MATLAB's path by the entry script.

WHAT WAS CHANGED
----------------
The uploaded original TOMOPSO_MAIN.m is a script for a single scalar-cost
PSO run. It does not itself contain the three ablation switches DTA, ALM,
and UCI. The earlier kit also converted TOMOPSO_MAIN.m into a function,
which meant typing TOMOPSO_MAIN did not launch the full ablation workflow.

This package fixes that interface:
- TOMOPSO_MAIN.m is now a SCRIPT entry point. Typing TOMOPSO_MAIN launches
  run_table10_ablation.m without requiring arguments.
- TAMOPSO_RUN.m is the callable optimizer used internally for one run.
- run_table10_ablation.m executes Full TAMOPSO, without DTA, without ALM,
  and without UCI.
- The required terrain, cost, coordinate-conversion, distance, and plotting
  helpers are included in the top-level folder.
- PlotSolution.m uses csaps if available and built-in pchip otherwise.
- Original uploaded source files are preserved under original_uploaded_source/.

DEFAULT SETTINGS
----------------
The entry script uses:
  nRuns    = 30
  nPop     = 500
  MaxIt    = 200
  nArchive = 200

The population, iteration, and archive values match the uploaded original
TOMOPSO_MAIN.m. The 30-run setting is a new verification setting; it must be
changed if the actual historical Table 10 protocol used another run count.
The output is a NEW verification experiment, not historical raw data.

QUICK SOFTWARE TEST
-------------------
Before committing to the full run, you may edit TOMOPSO_MAIN.m and change:
  cfg.nRuns = 1;
  cfg.nPop = 30;
  cfg.MaxIt = 10;
  cfg.nArchive = 30;
Run TOMOPSO_MAIN again. This is only a software smoke test, not data for a
scientific claim. Restore the intended protocol after the smoke test.

FILES IN THE TOP-LEVEL FOLDER
-----------------------------
TOMOPSO_MAIN.m                  Script entry point; type TOMOPSO_MAIN.
run_table10_ablation.m          Runs all four ablation configurations.
TAMOPSO_RUN.m                   One-run optimization engine with DTA/ALM/UCI.
CreateModel.m                   Terrain and scenario definition.
MyCost.m                        Original weighted scalar objective.
MyCostComponents_Table10.m      Component decomposition checked against MyCost.
SphericalToCart.m                Spherical-to-Cartesian path conversion.
DistP2S.m                       Point-to-segment threat-distance helper.
PlotModel.m                     Terrain plotting helper.
PlotSolution.m                  Path plotting helper; no mandatory csaps toolbox.
CreateRandomSolution.m           Original helper retained for compatibility.

OUTPUT FILES
------------
The output folder contains:
- Individual_Runs/*.mat: one MAT-file per run, with traces and metadata.
- Table10_RunLevel_Verification_Data.csv: all individual run-level metrics.
- Table10_Verification_Summary_NOT_ORIGINAL.csv: means, SDs, and cost changes.
- Table10_AllRun_Metadata_and_Traces.mat: summary plus all convergence traces.
- Mean_Convergence_Profiles_NEW_VERIFICATION.png: mean convergence plot.
- README_Verification_Run.txt: experiment settings and methodological notes.

IMPORTANT SCIENTIFIC LIMITATIONS
--------------------------------
This is an executable verification implementation based on the uploaded
project's terrain, spherical path representation, and weighted cost code,
plus the DTA/ALM/UCI mechanisms described in the manuscript. It is NOT a
recovered copy of the historical experimental implementation.

MATLAB VERSION
--------------
The package is intended for MATLAB R2024b, matching the version stated in
this project. The workflow uses base MATLAB functions such as table,
writetable, save, rng, and plotting. Plotting
uses csaps only if available, otherwise it uses interp1(...,'pchip').

TROUBLESHOOTING
---------------
If MATLAB says a function is undefined:
- Confirm you extracted the whole ZIP.
- Confirm Current Folder is the top-level package folder.
- Run: which TOMOPSO_MAIN -all
- Run: which TAMOPSO_RUN -all
- Make sure both resolve to this package, not an older folder on the path.
- Run: clear functions; rehash;
- Then run: TOMOPSO_MAIN

