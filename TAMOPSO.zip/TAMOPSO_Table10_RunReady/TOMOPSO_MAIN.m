
% HOW TO RUN:
%   1. Extract the complete package into one folder.
%   2. In MATLAB, open that folder as the Current Folder.
%   3. Type: TOMOPSO_MAIN
%   4. Press Enter.
%
% This is intentionally a SCRIPT (not a function), so typing TOMOPSO_MAIN
% starts the four-configuration workflow without requiring input arguments.


clc;
fprintf('\n============================================================\n');
fprintf('TAMOPSO - Table 10 ablation verification\n');
fprintf('============================================================\n');

% Resolve this script's own folder so its companion functions are found even
% if MATLAB's Current Folder was changed before this script was called.
thisFile = mfilename('fullpath');
if isempty(thisFile)
    projectDir = pwd;
else
    projectDir = fileparts(thisFile);
end
addpath(projectDir);

% Check all required companion files before starting an expensive run.
requiredFiles = { ...
    'run_table10_ablation.m', 'TAMOPSO_RUN.m', 'CreateModel.m', ...
    'MyCost.m', 'MyCostComponents_Table10.m', 'SphericalToCart.m', ...
    'DistP2S.m', 'PlotModel.m'};
missingFiles = {};
for k = 1:numel(requiredFiles)
    if exist(fullfile(projectDir, requiredFiles{k}), 'file') ~= 2
        missingFiles{end+1} = requiredFiles{k}; %#ok<SAGROW>
    end
end
if ~isempty(missingFiles)
    fprintf(2, '\nMissing required files:\n');
    for k = 1:numel(missingFiles)
        fprintf(2, '  - %s\n', missingFiles{k});
    end
    error('TAMOPSO:MissingPackageFiles', ...
        'The package is incomplete. Re-extract the full ZIP without moving individual files.');
end

% -------------------------------------------------------------------------
% Experiment settings.
% The population/iteration/archive values are retained from the uploaded
% TOMOPSO_MAIN.m. The 30-run setting is a verification setting; 
% -------------------------------------------------------------------------
cfg = struct();
cfg.nRuns = 100;
cfg.nPop = 500;
cfg.MaxIt = 200;
cfg.nArchive = 200;
cfg.baseSeed = 20261111;      
cfg.maxInitAttempts = 5000;
cfg.makePlotsEachRun = false;
cfg.verbose = false;
cfg.displayEvery = 25;
cfg.convergenceRelativeTolerance = 0.01;
cfg.outputRoot = fullfile(projectDir, 'Table10_Verification_Results');

% QUICK SOFTWARE TEST ONLY:
% To check that MATLAB can execute the package before the full run, change
% the settings above to: nRuns=1, nPop=30, MaxIt=10, nArchive=30.
% Such a short run is only a software test and is not suitable for reporting.

fprintf('Project folder: %s\n', projectDir);
fprintf('Runs per configuration: %d\n', cfg.nRuns);
fprintf('Population: %d | Iterations: %d | Archive capacity: %d\n', ...
    cfg.nPop, cfg.MaxIt, cfg.nArchive);
fprintf('\nStarting all four configurations...\n');

outputDir = run_table10_ablation(cfg);
assignin('base', 'TAMOPSO_Table10_OutputDir', outputDir);

fprintf('\n============================================================\n');
fprintf('Finished. Output folder:\n%s\n', outputDir);
fprintf('This output folder contains data pertaining to the proposed model\n');
fprintf('Raw data for "Table 10" associated with the proposed model.\n');
fprintf('============================================================\n\n');
