function f = MyCostComponents_Table10(sol, model)
% Return the four component costs used by the uploaded MyCost.m:
% f = [J1 path length, J2 threat penalty, J3 altitude penalty, J4 smoothness].
% Keep this implementation synchronized with MyCost.m.

    Jinf = inf;
    n = model.n;
    H = model.H;

    x = sol.x(:)';
    y = sol.y(:)';
    z = sol.z(:)';

    xs = model.start(1); ys = model.start(2); zs = model.start(3);
    xf = model.end(1);   yf = model.end(2);   zf = model.end(3);

    xAll = [xs x xf];
    yAll = [ys y yf];
    zAll = [zs z zf];

    N = numel(xAll);
    zAbs = zeros(1,N);
    for i = 1:N
        ix = min(model.MAPSIZE_X, max(1, round(xAll(i))));
        iy = min(model.MAPSIZE_Y, max(1, round(yAll(i))));
        zAbs(i) = zAll(i) + H(iy,ix);
    end

    % J1: total 3D path length using terrain-adjusted altitude.
    J1 = 0;
    for i = 1:N-1
        delta = [xAll(i+1)-xAll(i); yAll(i+1)-yAll(i); zAbs(i+1)-zAbs(i)];
        J1 = J1 + norm(delta);
    end

    % J2: threat / obstacle penalty (same conditions as uploaded MyCost.m).
    threats = model.threats;
    droneSize = 1;
    dangerDist = 10 * droneSize;
    J2 = 0;
    for k = 1:size(threats,1)
        threat = threats(k,:);
        threatXY = [threat(1) threat(2)];
        threatRadius = threat(4);
        for j = 1:N-1
            dist = DistP2S(threatXY, [xAll(j) yAll(j)], [xAll(j+1) yAll(j+1)]);
            if dist > (threatRadius + droneSize + dangerDist)
                threatCost = 0;
            elseif dist < (threatRadius + droneSize)
                threatCost = Jinf;
            else
                threatCost = (threatRadius + droneSize + dangerDist) - dist;
            end
            J2 = J2 + threatCost;
        end
    end

    % J3: altitude cost for intermediate waypoints.
    zmax = model.zmax; zmin = model.zmin;
    J3 = 0;
    for i = 1:n
        if z(i) < 0
            J3 = Jinf;
            break;
        else
            J3 = J3 + abs(z(i) - (zmax + zmin)/2);
        end
    end

    % J4: turn and climb smoothness penalty (same structure as MyCost.m).
    J4 = 0;
    turningMax = 45;
    climbMax = 45;
    for i = 1:N-2
        segment1Proj = [0;0;0];
        for j = i:-1:1
            segment1Proj = [xAll(j+1)-xAll(j); yAll(j+1)-yAll(j); 0];
            if any(segment1Proj ~= 0)
                break;
            end
        end
        segment2Proj = [0;0;0];
        for j = i:N-2
            segment2Proj = [xAll(j+2)-xAll(j+1); yAll(j+2)-yAll(j+1); 0];
            if any(segment2Proj ~= 0)
                break;
            end
        end

        climbAngle1 = atan2d(zAbs(i+1)-zAbs(i), norm(segment1Proj));
        climbAngle2 = atan2d(zAbs(i+2)-zAbs(i+1), norm(segment2Proj));
        turningAngle = atan2d(norm(cross(segment1Proj,segment2Proj)), ...
            dot(segment1Proj,segment2Proj));

        if abs(turningAngle) > turningMax
            J4 = J4 + abs(turningAngle);
        end
        if abs(climbAngle2-climbAngle1) > climbMax
            J4 = J4 + abs(climbAngle2-climbAngle1);
        end
    end

    f = [J1 J2 J3 J4];
end
