TAMOPSO TABLE 10 - NEW VERIFICATION PACKAGE
===========================================

IMPORTANT DATA-INTEGRITY NOTICE
-------------------------------
This package generates NEW computational verification results. It does NOT
recover historical raw data or original metadata from the experiments used
for the published Table 10. The user has indicated that no additional
historical run-level records are currently available. Do not describe these
new files as recovered original metadata when communicating with the journal.

HOW TO RUN
----------
1. Extract the complete ZIP to a writable folder.
2. Open MATLAB R2024b (or a compatible release).
3. Set the MATLAB Current Folder to the extracted folder containing
   TOMOPSO_MAIN.m.
4. Type:
       TOMOPSO_MAIN
5. The script runs four ablation configurations and creates a timestamped
   folder under Table10_Verification_Results.
6. At completion, BUILD_TABLE10_METADATA.m creates:
   Table10_Metadata_and_Verification_Results.xlsx
   with worksheets Summary, RunLevelResults, RunMetadata, Provenance,
   and AlgorithmParameters. The summary table is also displayed in MATLAB.

NEW VERIFICATION DEFAULTS
-------------------------
Runs per configuration: 30
Population:              500
Iterations:              200
Archive capacity:        200
Base seed:               20261128

These settings are a newly selected verification protocol. They are NOT
claimed to match the historical Table 10 protocol. Change them only with a
written rationale and record the actual values used.

FOUR CONFIGURATIONS
-------------------
1. Full TAMOPSO
2. TAMOPSO without DTA
3. TAMOPSO without ALM
4. TAMOPSO without UCI

OUTPUTS
-------
- Individual_Runs/*.mat: one saved result per configuration and run.
- Table10_RunLevel_Verification_Data.csv: run-level metrics.
- Table10_Verification_Summary_NOT_ORIGINAL.csv: means, standard deviations,
  convergence iteration, diversity proxy, archive size and relative cost.
- Table10_AllRun_Metadata_and_Traces.mat: run summaries and convergence traces.
- Table10_Metadata_and_Verification_Results.xlsx: Excel workbook with five
  sheets containing summary, run-level results, run metadata, provenance,
  and algorithm parameter settings.
- Mean_Convergence_Profiles_NEW_VERIFICATION.png: convergence plot.
- READ_ME_DATA_STATUS.txt: explicit data-provenance notice.

SCIENTIFIC LIMITATIONS THAT MUST BE RETAINED
--------------------------------------------
1. The original uploaded TOMOPSO_MAIN.m is a single scalar-cost PSO source;
   it does not itself contain the three ablation switches DTA, ALM and UCI.
   The current TAMOPSO_RUN.m is an executable verification implementation
   that adds operational implementations of those mechanisms based on the
   manuscript description. It is not proof of the historical implementation.
2. DTA role assignment uses rank terciles because exact numerical role
   cut-points are not specified in the supplied project materials.
3. The diversity output is a nearest-neighbour diversity proxy. It is not
   asserted to be identical to the published Pareto Diversity Index (PDI)
   unless the original PDI formula is independently established.
4. The UCI ablation must be inspected: if disabling UCI does not alter the
   result for a particular run, report that result honestly. Do not force a
   numerical difference or alter results to match the expected narrative.
5. The new outputs may differ from the published Table 10. Do not overwrite
   the published values or present new results as recovered old results.
6. Before using any output as a correction to the article, compare the exact
   objective definitions, terrain, algorithm equations, parameter settings,
   and metric definitions with the published methods and original research
   records. If these cannot be established, describe the limits explicitly.

SOFTWARE
--------
The package is intended for MATLAB R2024b and uses standard MATLAB functions
for tables, MAT files, random number generation, and plotting. The original
source files are preserved in original_uploaded_source/.

QUICK TEST
----------
For a software smoke test only, edit TOMOPSO_MAIN.m to use nRuns=1,
nPop=30, MaxIt=10, nArchive=30. This is only a functionality check and is
not a scientifically adequate experiment or a journal-ready result.
