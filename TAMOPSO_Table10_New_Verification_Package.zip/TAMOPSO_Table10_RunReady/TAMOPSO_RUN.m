function result = TAMOPSO_RUN(userCfg)
% TAMOPSO_RUN  Single-run TAMOPSO / ablation experiment.
%
% This file is a reproducibility-oriented implementation for the uploaded
% project. It retains the project's CreateModel, SphericalToCart, MyCost,
% and DistP2S model, and adds explicit DTA, ALM, and UCI switches.
%
% IMPORTANT RESEARCH-INTEGRITY NOTE:
% This implementation can generate NEW verification experiments. It cannot
% recreate or prove the provenance of historical results unless the exact
% original source version, parameter settings, and random seeds are known.
% The paper does not fully specify PECRI role cut-points or the Pareto
% Diversity Index formula; the transparent operational choices are stated
% in README_Table10.md and in the run metadata.
%
% Usage:
%   cfg = struct('variant','Full TAMOPSO','seed',20261111,...
%                'nPop',100,'MaxIt',50,'makePlots',false);
%   R = TAMOPSO_RUN(cfg);
%
% The script TOMOPSO_MAIN.m calls run_table10_ablation.m.

    if nargin < 1 || isempty(userCfg)
        userCfg = struct();
    end
    cfg = localDefaults(userCfg);

    if exist('CreateModel','file') ~= 2 || exist('SphericalToCart','file') ~= 2 || ...
            exist('MyCost','file') ~= 2 || exist('DistP2S','file') ~= 2
        error('TAMOPSO:MissingDependency', ...
            ['Place this file in the same folder as CreateModel.m, ', ...
             'SphericalToCart.m, MyCost.m, and DistP2S.m.']);
    end

    rng(cfg.seed, 'twister');
    rngStateStart = rng;
    startedAt = datestr(now, 30);
    runClock = tic;

    % CreateModel(false) suppresses terrain plotting during repeated runs.
    model = CreateModel(false);
    nVar = model.n;
    VarSize = [1 nVar]; %#ok<NASGU>

    VarMin.x = model.xmin; VarMax.x = model.xmax;
    VarMin.y = model.ymin; VarMax.y = model.ymax;
    VarMin.z = model.zmin; VarMax.z = model.zmax;

    VarMax.r = 2 * norm(model.start - model.end) / nVar;
    VarMin.r = 0;

    angleRange = pi/4;
    VarMin.psi = -angleRange; VarMax.psi = angleRange;
    dirVector = model.end - model.start;
    phi0 = atan2(dirVector(2), dirVector(1));
    VarMin.phi = phi0 - angleRange; VarMax.phi = phi0 + angleRange;

    alphaVel = 0.5;  % Retained from the uploaded TOMOPSO_MAIN.m.
    VelMax.r = alphaVel * (VarMax.r - VarMin.r); VelMin.r = -VelMax.r;
    VelMax.psi = alphaVel * (VarMax.psi - VarMin.psi); VelMin.psi = -VelMax.psi;
    VelMax.phi = alphaVel * (VarMax.phi - VarMin.phi); VelMin.phi = -VelMax.phi;

    % Particle state.
    template.Position = [];
    template.Velocity = [];
    template.Obj = [];
    template.Cost = inf;
    template.Best.Position = [];
    template.Best.Obj = [];
    template.Best.Cost = inf;
    template.Stagnation = 0;

    particle = repmat(template, cfg.nPop, 1);
    archive = struct('Position', {}, 'Obj', {}, 'Cost', {});

    % Initialize only feasible finite-cost particles. Rejection sampling is
    % recorded in the run result; it does not fabricate or overwrite data.
    initAttempts = zeros(cfg.nPop, 1);
    for i = 1:cfg.nPop
        accepted = false;
        for attempt = 1:cfg.maxInitAttempts
            pos = localRandomPosition(VarMin, VarMax, nVar);
            [obj, cost, isValid] = localEvaluate(pos, model);
            initAttempts(i) = attempt;
            if isValid
                accepted = true;
                particle(i).Position = pos;
                particle(i).Velocity.r = zeros(1, nVar);
                particle(i).Velocity.psi = zeros(1, nVar);
                particle(i).Velocity.phi = zeros(1, nVar);
                particle(i).Obj = obj;
                particle(i).Cost = cost;
                particle(i).Best.Position = pos;
                particle(i).Best.Obj = obj;
                particle(i).Best.Cost = cost;
                particle(i).Stagnation = 0;
                archive = localUpdateArchive(archive, particle(i), cfg.nArchive, cfg.useUCI);
                break;
            end
        end
        if ~accepted
            error('TAMOPSO:InitializationFailed', ...
                ['Could not initialize a feasible particle after %d attempts. ', ...
                 'Check the terrain, objective function, or initial path bounds.'], ...
                 cfg.maxInitAttempts);
        end
    end

    % Historical scalar incumbent is retained independently of archive
    % pruning so the best-so-far cost trace is monotone non-increasing.
    allInitialCosts = [particle.Cost];
    [historicalBestCost, bestIdx] = min(allInitialCosts);
    historicalBestPosition = particle(bestIdx).Position;

    previousCost = allInitialCosts(:);
    bestCostTrace = nan(cfg.MaxIt, 1);
    archiveSizeTrace = zeros(cfg.MaxIt, 1);
    diversityProxyTrace = nan(cfg.MaxIt, 1);
    roleCounts = zeros(cfg.MaxIt, 3); % [explorer, refiner, altitude manager]
    mutationCount = zeros(cfg.MaxIt, 1);
    invalidCandidateCount = zeros(cfg.MaxIt, 1);
    meanMutationProbability = zeros(cfg.MaxIt, 1);

    for it = 1:cfg.MaxIt
        oldCosts = [particle.Cost]';

        % DTA role assignment using the paper's PECRI expression. The paper
        % does not define numerical cut-points; rank terciles are used here.
        if cfg.useDTA
            pecri = (previousCost - oldCosts) ./ (max(max(previousCost - oldCosts), eps));
            roles = localAssignRoles(pecri);
        else
            roles = ones(cfg.nPop, 1); % One homogeneous PSO group.
        end
        roleCounts(it,1) = sum(roles == 1);
        roleCounts(it,2) = sum(roles == 2);
        roleCounts(it,3) = sum(roles == 3);

        dispersion = localPopulationDispersion(particle, VarMin, VarMax);
        convergenceLevel = 1 - min(1, dispersion / cfg.dispersionScale);
        convergenceLevel = max(0, min(1, convergenceLevel));
        adaptiveMutationProbability = cfg.mutationBaseProbability + ...
            cfg.mutationProbabilityGain * convergenceLevel;
        adaptiveMutationProbability = min(cfg.mutationMaxProbability, ...
            max(cfg.mutationBaseProbability, adaptiveMutationProbability));
        meanMutationProbability(it) = adaptiveMutationProbability;

        for i = 1:cfg.nPop
            guide = archive(randi(numel(archive)));
            currentPosition = particle(i).Position;

            if cfg.useDTA
                role = roles(i);
                [rho, c1, c2] = localRoleParameters(role, cfg);
                omega = cfg.wMax - ((cfg.wMax - cfg.wMin) * it / cfg.MaxIt) * rho;
                omega = max(0.05, omega);
            else
                role = 0;
                omega = cfg.wMax - (cfg.wMax - cfg.wMin) * it / cfg.MaxIt;
                c1 = cfg.c1;
                c2 = cfg.c2;
            end

            % Standard PSO velocity update in spherical variables.
            v = omega * particle(i).Velocity.r + ...
                c1 * rand(size(currentPosition.r)) .* ...
                (particle(i).Best.Position.r - currentPosition.r) + ...
                c2 * rand(size(currentPosition.r)) .* ...
                (guide.Position.r - currentPosition.r);
            particle(i).Velocity.r = max(min(v, VelMax.r), VelMin.r);

            v = omega * particle(i).Velocity.psi + ...
                c1 * rand(size(currentPosition.psi)) .* ...
                (particle(i).Best.Position.psi - currentPosition.psi) + ...
                c2 * rand(size(currentPosition.psi)) .* ...
                (guide.Position.psi - currentPosition.psi);
            particle(i).Velocity.psi = max(min(v, VelMax.psi), VelMin.psi);

            v = omega * particle(i).Velocity.phi + ...
                c1 * rand(size(currentPosition.phi)) .* ...
                (particle(i).Best.Position.phi - currentPosition.phi) + ...
                c2 * rand(size(currentPosition.phi)) .* ...
                (guide.Position.phi - currentPosition.phi);
            particle(i).Velocity.phi = max(min(v, VelMax.phi), VelMin.phi);

            % Apply role-specific altitude-manager scaling BEFORE updating
            % all three position coordinates. This ensures the r/psi/phi
            % velocity modifications affect the current candidate.
            if cfg.useDTA && role == 3
                particle(i).Velocity.r = cfg.altitudeRoleHorizontalScale * particle(i).Velocity.r;
                particle(i).Velocity.phi = cfg.altitudeRoleHorizontalScale * particle(i).Velocity.phi;
                particle(i).Velocity.psi = cfg.altitudeRoleVerticalScale * particle(i).Velocity.psi;
            end

            candidate.r = currentPosition.r + particle(i).Velocity.r;
            [candidate.r, particle(i).Velocity.r] = ...
                localEnforceBounds(candidate.r, particle(i).Velocity.r, VarMin.r, VarMax.r);
            candidate.psi = currentPosition.psi + particle(i).Velocity.psi;
            [candidate.psi, particle(i).Velocity.psi] = ...
                localEnforceBounds(candidate.psi, particle(i).Velocity.psi, VarMin.psi, VarMax.psi);
            candidate.phi = currentPosition.phi + particle(i).Velocity.phi;
            [candidate.phi, particle(i).Velocity.phi] = ...
                localEnforceBounds(candidate.phi, particle(i).Velocity.phi, VarMin.phi, VarMax.phi);

            % ALM: stagnation-triggered archive-guided Levy mutation.
            didMutate = false;
            if cfg.useALM && particle(i).Stagnation >= cfg.stagnationIterations && ...
                    rand < adaptiveMutationProbability
                candidate = localLevyMutation(candidate, guide.Position, ...
                    VarMin, VarMax, cfg, convergenceLevel);
                didMutate = true;
                mutationCount(it) = mutationCount(it) + 1;
            end

            [candidateObj, candidateCost, isValid] = localEvaluate(candidate, model);
            if isValid
                oldPersonalBest = particle(i).Best.Cost;
                particle(i).Position = candidate;
                particle(i).Obj = candidateObj;
                particle(i).Cost = candidateCost;

                if localDominates(candidateObj, particle(i).Best.Obj) || ...
                        (~localDominates(particle(i).Best.Obj, candidateObj) && ...
                         candidateCost < particle(i).Best.Cost)
                    particle(i).Best.Position = candidate;
                    particle(i).Best.Obj = candidateObj;
                    particle(i).Best.Cost = candidateCost;
                end

                if particle(i).Best.Cost < oldPersonalBest - cfg.improvementTolerance
                    particle(i).Stagnation = 0;
                else
                    particle(i).Stagnation = particle(i).Stagnation + 1;
                end

                archive = localUpdateArchive(archive, particle(i), cfg.nArchive, cfg.useUCI);
                if candidateCost < historicalBestCost
                    historicalBestCost = candidateCost;
                    historicalBestPosition = candidate;
                end
            else
                invalidCandidateCount(it) = invalidCandidateCount(it) + 1;
                % Retain the last valid position and reverse the attempted
                % velocities to avoid propagating infeasible states.
                particle(i).Velocity.r = -0.5 * particle(i).Velocity.r;
                particle(i).Velocity.psi = -0.5 * particle(i).Velocity.psi;
                particle(i).Velocity.phi = -0.5 * particle(i).Velocity.phi;
                particle(i).Stagnation = particle(i).Stagnation + 1;
            end

            if didMutate && ~isValid
                % Count is still retained: a mutation was attempted, though
                % its candidate was rejected as infeasible.
            end
        end

        bestCostTrace(it) = historicalBestCost;
        archiveSizeTrace(it) = numel(archive);
        diversityProxyTrace(it) = localDiversityProxy(archive);
        previousCost = oldCosts;

        if cfg.verbose && (it == 1 || mod(it, cfg.displayEvery) == 0 || it == cfg.MaxIt)
            fprintf('%s | iteration %d/%d | best cost %.8g | archive %d\n', ...
                cfg.variant, it, cfg.MaxIt, historicalBestCost, numel(archive));
        end
    end

    % A transparent, reproducible convergence definition: first iteration
    % at which best-so-far is within relTol of the final run-best cost.
    finalBestCost = historicalBestCost;
    convThreshold = finalBestCost + cfg.convergenceRelativeTolerance * ...
        max(abs(finalBestCost), eps);
    convergenceIteration = find(bestCostTrace <= convThreshold, 1, 'first');
    if isempty(convergenceIteration)
        convergenceIteration = cfg.MaxIt;
    end

    finalArchiveObj = vertcat(archive.Obj);
    finalArchiveCost = vertcat(archive.Cost);
    diversityProxy = localDiversityProxy(archive);
    bestPath = SphericalToCart(historicalBestPosition, model);

    if cfg.makePlots
        PlotModel(model);
        PlotSolution(bestPath, model, 0.95);
        figure('Name', ['Convergence - ' cfg.variant]);
        plot(bestCostTrace, 'LineWidth', 1.7);
        xlabel('Iteration'); ylabel('Best-so-far scalar cost'); grid on;
        title(cfg.variant, 'Interpreter', 'none');
    end

    result = struct();
    result.variant = cfg.variant;
    result.seed = cfg.seed;
    result.configuration = cfg;
    result.startedAt = startedAt;
    result.finishedAt = datestr(now, 30);
    result.elapsedSeconds = toc(runClock);
    result.matlabVersion = version;
    result.computer = computer;
    result.rngStateStart = rngStateStart;
    result.rngStateEnd = rng;
    result.initializationAttempts = initAttempts;
    result.finalBestCostRaw = finalBestCost;
    result.finalBestCostTimes1eMinus3 = finalBestCost / 1e3;
    result.convergenceIteration_1pct = convergenceIteration;
    result.convergenceRelativeTolerance = cfg.convergenceRelativeTolerance;
    result.bestCostTrace = bestCostTrace;
    result.archiveSizeTrace = archiveSizeTrace;
    result.diversityProxyTrace = diversityProxyTrace;
    result.diversityProxyFinal = diversityProxy;
    result.diversityMetricDefinition = ...
        'Mean nearest-neighbour Euclidean distance after per-objective min-max scaling, divided by sqrt(number of objectives). This is a proxy, not a recovered published PDI formula.';
    result.roleCounts = roleCounts;
    result.mutationCount = mutationCount;
    result.meanMutationProbability = meanMutationProbability;
    result.invalidCandidateCount = invalidCandidateCount;
    result.finalArchive = archive;
    result.finalArchiveObjectives = finalArchiveObj;
    result.finalArchiveCosts = finalArchiveCost;
    result.finalBestDecision = historicalBestPosition;
    result.finalBestPath = bestPath;
    result.finalPopulation = particle;
end

function cfg = localDefaults(userCfg)
    cfg.variant = 'Full TAMOPSO';
    cfg.useDTA = true;
    cfg.useALM = true;
    cfg.useUCI = true;
    cfg.seed = 1;
    cfg.nPop = 100;
    cfg.MaxIt = 100;
    cfg.nArchive = 100;
    cfg.maxInitAttempts = 500;
    cfg.wMax = 0.9;
    cfg.wMin = 0.3;
    cfg.c1 = 1.5;
    cfg.c2 = 1.5;
    cfg.explorerRho = 1.25;
    cfg.refinerRho = 0.75;
    cfg.altitudeRho = 1.00;
    cfg.explorerC1 = 1.8;
    cfg.explorerC2 = 1.2;
    cfg.refinerC1 = 1.2;
    cfg.refinerC2 = 1.8;
    cfg.altitudeC1 = 1.5;
    cfg.altitudeC2 = 1.5;
    cfg.altitudeRoleHorizontalScale = 0.75;
    cfg.altitudeRoleVerticalScale = 1.35;
    cfg.stagnationIterations = 5;
    cfg.mutationBaseProbability = 0.05;
    cfg.mutationProbabilityGain = 0.45;
    cfg.mutationMaxProbability = 0.50;
    cfg.levyBeta = 1.5;
    cfg.levyAlpha = 0.01;
    cfg.levyClip = 10;
    cfg.dispersionScale = 0.25;
    cfg.convergenceRelativeTolerance = 0.01;
    cfg.improvementTolerance = 1e-12;
    cfg.makePlots = false;
    cfg.verbose = true;
    cfg.displayEvery = 10;

    names = fieldnames(userCfg);
    for k = 1:numel(names)
        if ~isfield(cfg, names{k})
            error('TAMOPSO:UnknownOption', 'Unknown option: %s', names{k});
        end
        cfg.(names{k}) = userCfg.(names{k});
    end

    if cfg.nPop < 6 || cfg.MaxIt < 1 || cfg.nArchive < 2
        error('TAMOPSO:InvalidOptions', 'Require nPop >= 6, MaxIt >= 1, nArchive >= 2.');
    end
    if cfg.levyBeta <= 1 || cfg.levyBeta >= 3
        error('TAMOPSO:InvalidLevyBeta', 'levyBeta must satisfy 1 < beta < 3.');
    end
end

function pos = localRandomPosition(VarMin, VarMax, nVar)
    pos.r = VarMin.r + rand(1,nVar) .* (VarMax.r - VarMin.r);
    pos.psi = VarMin.psi + rand(1,nVar) .* (VarMax.psi - VarMin.psi);
    pos.phi = VarMin.phi + rand(1,nVar) .* (VarMax.phi - VarMin.phi);
end

function [obj, cost, valid] = localEvaluate(pos, model)
    cart = SphericalToCart(pos, model);
    obj = MyCostComponents_Table10(cart, model);
    cost = MyCost(cart, model);
    valid = all(~isnan(obj) & ~isinf(obj)) && ~isnan(cost) && ~isinf(cost) && isreal(cost);
    if ~valid
        obj = [inf inf inf inf];
        cost = inf;
        return;
    end

    % Guard against a mismatch between the component decomposition and the
    % uploaded MyCost.m. The supplied project uses weights [5 1 10 1].
    costFromComponents = 5*obj(1) + obj(2) + 10*obj(3) + obj(4);
    if abs(costFromComponents - cost) > 1e-7 * max(1, abs(cost))
        error('TAMOPSO:CostMismatch', ...
            'MyCost.m differs from MyCostComponents_Table10.m; reconcile the objective definitions before running experiments.');
    end
end

function roles = localAssignRoles(pecri)
    n = numel(pecri);
    % Explicit operational choice: rank-based terciles because the article
    % defines PECRI but does not publish numerical role cut-points.
    tieBreak = rand(size(pecri)) * 1e-12;
    [~, order] = sort(pecri + tieBreak, 'descend');
    nRefiner = max(1, floor(n/3));
    nAltitude = max(1, floor(n/3));
    roles = ones(n,1); % 1=explorer
    roles(order(1:nRefiner)) = 2; % 2=refiner (highest PECRI)
    altIdx = order(nRefiner+1:min(n, nRefiner+nAltitude));
    roles(altIdx) = 3; % 3=altitude manager
end

function [rho, c1, c2] = localRoleParameters(role, cfg)
    switch role
        case 1 % global explorer
            rho = cfg.explorerRho; c1 = cfg.explorerC1; c2 = cfg.explorerC2;
        case 2 % local refiner
            rho = cfg.refinerRho; c1 = cfg.refinerC1; c2 = cfg.refinerC2;
        otherwise % altitude manager
            rho = cfg.altitudeRho; c1 = cfg.altitudeC1; c2 = cfg.altitudeC2;
    end
end

function dispersion = localPopulationDispersion(particle, VarMin, VarMax)
    n = numel(particle);
    X = zeros(n, numel(particle(1).Position.r) * 3);
    for i = 1:n
        p = particle(i).Position;
        X(i,:) = [ ...
            (p.r - VarMin.r) ./ max(VarMax.r-VarMin.r,eps), ...
            (p.psi - VarMin.psi) ./ max(VarMax.psi-VarMin.psi,eps), ...
            (p.phi - VarMin.phi) ./ max(VarMax.phi-VarMin.phi,eps)];
    end
    dispersion = mean(std(X, 0, 1));
end

function pos = localLevyMutation(pos, guidePos, VarMin, VarMax, cfg, convergenceLevel)
    x = [pos.r, pos.psi, pos.phi];
    xa = [guidePos.r, guidePos.psi, guidePos.phi];
    beta = cfg.levyBeta;
    sigmaU = (gamma(1+beta) * sin(pi*beta/2) / ...
        (gamma((1+beta)/2) * beta * 2^((beta-1)/2)))^(1/beta);
    u = randn(size(x)) * sigmaU;
    v = randn(size(x));
    levy = u ./ (abs(v).^(1/beta) + eps);
    levy = max(-cfg.levyClip, min(cfg.levyClip, levy));
    alpha = cfg.levyAlpha * (0.5 + convergenceLevel);
    xNew = x + alpha .* levy .* (x - xa);

    n = numel(pos.r);
    pos.r = xNew(1:n);
    pos.psi = xNew(n+1:2*n);
    pos.phi = xNew(2*n+1:3*n);

    [pos.r, ~] = localEnforceBounds(pos.r, zeros(size(pos.r)), VarMin.r, VarMax.r);
    [pos.psi, ~] = localEnforceBounds(pos.psi, zeros(size(pos.psi)), VarMin.psi, VarMax.psi);
    [pos.phi, ~] = localEnforceBounds(pos.phi, zeros(size(pos.phi)), VarMin.phi, VarMax.phi);
end

function [pos, vel] = localEnforceBounds(pos, vel, lb, ub)
    out = pos < lb | pos > ub;
    vel(out) = -vel(out);
    pos = min(max(pos, lb), ub);
end

function tf = localDominates(a, b)
    tol = 1e-12;
    tf = all(a <= b + tol) && any(a < b - tol);
end

function archive = localUpdateArchive(archive, particle, maxSize, useUCI)
    candidate.Position = particle.Position;
    candidate.Obj = particle.Obj;
    candidate.Cost = particle.Cost;
    if isempty(archive)
        archive = candidate;
        return;
    end

    combined = [archive(:); candidate];
    O = vertcat(combined.Obj);
    n = size(O,1);
    keep = true(n,1);

    for i = 1:n
        for j = 1:n
            if i ~= j && localDominates(O(j,:), O(i,:))
                keep(i) = false;
                break;
            end
        end
    end
    combined = combined(keep);

    % Remove near-identical objective vectors, retaining the lower scalar cost.
    if numel(combined) > 1
        O = vertcat(combined.Obj);
        drop = false(numel(combined),1);
        for i = 1:numel(combined)
            if drop(i), continue; end
            for j = i+1:numel(combined)
                if ~drop(j) && norm(O(i,:)-O(j,:)) <= 1e-10
                    if combined(j).Cost < combined(i).Cost
                        drop(i) = true;
                        break;
                    else
                        drop(j) = true;
                    end
                end
            end
        end
        combined = combined(~drop);
    end

    if numel(combined) > maxSize
        if useUCI
            O = vertcat(combined.Obj);
            lo = min(O,[],1); hi = max(O,[],1);
            On = (O - lo) ./ max(hi-lo, eps);
            D = zeros(size(On,1));
            for i = 1:size(On,1)
                for j = i+1:size(On,1)
                    d = norm(On(i,:) - On(j,:));
                    D(i,j) = d; D(j,i) = d;
                end
            end
            E = exp(-D);
            E(1:size(E,1)+1:end) = 0;
            uci = 1 ./ (1 + sum(E,2));
            tieCost = [combined.Cost]';
            rankTable = [-uci, tieCost];
            [~, order] = sortrows(rankTable, [1 2]);
            combined = combined(order(1:maxSize));
        else
            % Ablation without UCI: keep the nondominated archive but use
            % uniform random truncation when the capacity is exceeded.
            order = randperm(numel(combined), maxSize);
            combined = combined(order);
        end
    end
    archive = combined(:);
end

function value = localDiversityProxy(archive)
    % Not a recovered formula from the article. It is a transparent proxy:
    % mean nearest-neighbour distance in min-max-scaled objective space,
    % divided by sqrt(M), so the result lies in [0,1] for scaled objectives.
    if numel(archive) < 2
        value = 0;
        return;
    end
    O = vertcat(archive.Obj);
    lo = min(O,[],1); hi = max(O,[],1);
    On = (O - lo) ./ max(hi-lo, eps);
    n = size(On,1);
    nearest = inf(n,1);
    for i = 1:n
        for j = 1:n
            if i ~= j
                nearest(i) = min(nearest(i), norm(On(i,:) - On(j,:)));
            end
        end
    end
    value = mean(nearest) / sqrt(size(On,2));
    value = max(0, min(1, value));
end
