Software Requirements, Dependencies, and Execution Environment

Successful execution and reproduction of the simulations in this project require an appropriately configured MATLAB environment and the installation of all necessary software components, libraries, and dependencies. The code was developed and configured for execution using MATLAB R2024b under Windows 11. Before running the project, users should ensure that a compatible MATLAB installation is available, all required MATLAB toolboxes and any external functions or third-party libraries referenced by the source code are installed and accessible, and all supplementary MATLAB scripts, function files, input datasets, terrain models, and configuration files are located in their designated directories and included in the MATLAB search path. Adequate computational resources, including sufficient RAM, processing capacity, and disk space, are also necessary, particularly when performing multiple independent simulation runs with large populations and high iteration limits. Furthermore, the simulation parameters, algorithm configurations, objective-function definitions, and random-number-generation settings should be checked and configured appropriately before execution. Differences in MATLAB versions, operating systems, toolbox releases, or dependency configurations may affect compatibility, computational performance, and numerical results. Therefore, users are strongly advised to verify all prerequisites, dependency versions, folder structures, and configuration settings before initiating the simulations. Full and successful execution of the project, as well as the reproducibility and consistency of its computational results, depends on satisfying these software, hardware, and configuration requirements.


Created: 20251112T090454
MATLAB version: 24.2.0.2712019 (R2024b)
Computer: PCWIN64
Runs/configuration: 100
Population: 500
Iterations: 200, 300, 500
Archive: 200
Base seed: 20261111 (new verification seed series)
Convergence iteration definition: first best-so-far iteration within 0.01 relative tolerance of final best-so-far cost.
Diversity column is a nearest-neighbour diversity proxy, NOT the published PDI unless independently confirmed.
DTA uses rank terciles because the paper does not specify exact role cut-points.
ALM uses Mantegna Levy-flight sampling with parameters stored in each run file.
UCI uses exponential-distance archive pruning on scaled objective vectors.
Scalar cost is the supplied MyCost.m with component weights [5 1 10 1].
