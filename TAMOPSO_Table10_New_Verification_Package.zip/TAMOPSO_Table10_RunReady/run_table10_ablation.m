function outputDir = run_table10_ablation(userCfg)
%RUN_TABLE10_ABLATION Run all four ablation configurations and save evidence.
% This produces NEW verification experiments. It does not recreate the
% historical runs used for the published Table 10.

if nargin < 1 || isempty(userCfg), userCfg = struct(); end

cfg.nRuns = 30;
cfg.nPop = 500;
cfg.MaxIt = 200;
cfg.nArchive = 200;
cfg.baseSeed = 20261111;
cfg.maxInitAttempts = 5000;
cfg.makePlotsEachRun = false;
cfg.verbose = false;
cfg.displayEvery = 25;
cfg.convergenceRelativeTolerance = 0.01;
cfg.outputRoot = fullfile(pwd, 'Table10_Verification_Results');

fields = fieldnames(userCfg);
for k = 1:numel(fields)
    if ~isfield(cfg, fields{k})
        error('TAMOPSO:UnknownRunnerOption', 'Unknown runner option: %s', fields{k});
    end
    cfg.(fields{k}) = userCfg.(fields{k});
end

validateattributes(cfg.nRuns, {'numeric'}, {'scalar','integer','positive'});
validateattributes(cfg.nPop, {'numeric'}, {'scalar','integer','>=',6});
validateattributes(cfg.MaxIt, {'numeric'}, {'scalar','integer','positive'});
validateattributes(cfg.nArchive, {'numeric'}, {'scalar','integer','>=',2});
validateattributes(cfg.baseSeed, {'numeric'}, {'scalar','integer','nonnegative'});

required = {'TAMOPSO_RUN','CreateModel','SphericalToCart','MyCost', ...
    'MyCostComponents_Table10','DistP2S'};
for k = 1:numel(required)
    if exist(required{k}, 'file') ~= 2
        error('TAMOPSO:MissingDependency', ...
            'Missing %s.m. Keep all package .m files in the same folder.', required{k});
    end
end

if ~exist(cfg.outputRoot, 'dir'), mkdir(cfg.outputRoot); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
outputDir = fullfile(cfg.outputRoot, ['Verification_' stamp]);
if ~exist(outputDir, 'dir'), mkdir(outputDir); end
runDir = fullfile(outputDir, 'Individual_Runs');
if ~exist(runDir, 'dir'), mkdir(runDir); end

variants = struct( ...
    'name', {'Full TAMOPSO','TAMOPSO without DTA','TAMOPSO without ALM','TAMOPSO without UCI'}, ...
    'useDTA', {true,false,true,true}, ...
    'useALM', {true,true,false,true}, ...
    'useUCI', {true,true,true,false});

nTotal = numel(variants) * cfg.nRuns;
rowVariant = cell(nTotal,1);
rowRun = nan(nTotal,1);
rowSeed = nan(nTotal,1);
rowCostRaw = nan(nTotal,1);
rowCostScaled = nan(nTotal,1);
rowConv = nan(nTotal,1);
rowDivProxy = nan(nTotal,1);
rowArchiveSize = nan(nTotal,1);
rowElapsed = nan(nTotal,1);
runSummary = repmat(struct('variant','','run',0,'seed',0, ...
    'bestCostTrace',[],'finalBestCostRaw',NaN, ...
    'convergenceIteration_1pct',NaN,'diversityProxyFinal',NaN, ...
    'archiveSize',NaN), nTotal, 1);

fprintf('Ablation verification: %d runs x %d configurations.\n', cfg.nRuns, numel(variants));
row = 0;
try
    for v = 1:numel(variants)
        for r = 1:cfg.nRuns
            row = row + 1;
            runCfg = struct();
            runCfg.variant = variants(v).name;
            runCfg.useDTA = variants(v).useDTA;
            runCfg.useALM = variants(v).useALM;
            runCfg.useUCI = variants(v).useUCI;
            runCfg.seed = cfg.baseSeed + r - 1; % Matched seed by run index.
            runCfg.nPop = cfg.nPop;
            runCfg.MaxIt = cfg.MaxIt;
            runCfg.nArchive = cfg.nArchive;
            runCfg.maxInitAttempts = cfg.maxInitAttempts;
            runCfg.makePlots = cfg.makePlotsEachRun;
            runCfg.verbose = cfg.verbose;
            runCfg.displayEvery = cfg.displayEvery;
            runCfg.convergenceRelativeTolerance = cfg.convergenceRelativeTolerance;

            fprintf('Configuration %d/%d: %s | run %d/%d | seed %d\n', ...
                v, numel(variants), variants(v).name, r, cfg.nRuns, runCfg.seed);
            R = TAMOPSO_RUN(runCfg);

            rowVariant{row} = variants(v).name;
            rowRun(row) = r;
            rowSeed(row) = runCfg.seed;
            rowCostRaw(row) = R.finalBestCostRaw;
            rowCostScaled(row) = R.finalBestCostTimes1eMinus3;
            rowConv(row) = R.convergenceIteration_1pct;
            rowDivProxy(row) = R.diversityProxyFinal;
            rowArchiveSize(row) = numel(R.finalArchive);
            rowElapsed(row) = R.elapsedSeconds;

            runSummary(row).variant = variants(v).name;
            runSummary(row).run = r;
            runSummary(row).seed = runCfg.seed;
            runSummary(row).bestCostTrace = R.bestCostTrace;
            runSummary(row).finalBestCostRaw = R.finalBestCostRaw;
            runSummary(row).convergenceIteration_1pct = R.convergenceIteration_1pct;
            runSummary(row).diversityProxyFinal = R.diversityProxyFinal;
            runSummary(row).archiveSize = numel(R.finalArchive);

            safeName = regexprep(variants(v).name, '[^A-Za-z0-9]+', '_');
            runFile = fullfile(runDir, sprintf('%s_run_%03d_seed_%d.mat', ...
                safeName, r, runCfg.seed));
            runResult = R; %#ok<NASGU>
            save(runFile, 'runResult', '-v7.3');
            clear R runResult;
        end
    end
catch ME
    % Preserve a failure report and all completed individual run files.
    failureFile = fullfile(outputDir, 'RUN_FAILED_read_this_first.txt');
    fid = fopen(failureFile, 'w');
    if fid >= 0
        fprintf(fid, 'The verification run stopped before completion.\n\n');
        fprintf(fid, 'Completed runs: %d of %d\n', row-1, nTotal);
        fprintf(fid, 'Error identifier: %s\n', ME.identifier);
        fprintf(fid, 'Error message: %s\n\n', ME.message);
        for q = 1:numel(ME.stack)
            fprintf(fid, 'File: %s | Line: %d | Function: %s\n', ...
                ME.stack(q).file, ME.stack(q).line, ME.stack(q).name);
        end
        fclose(fid);
    end
    save(fullfile(outputDir, 'Partial_Run_State.mat'), ...
        'cfg','variants','rowVariant','rowRun','rowSeed','rowCostRaw', ...
        'rowCostScaled','rowConv','rowDivProxy','rowArchiveSize','rowElapsed', ...
        'runSummary','-v7.3');
    rethrow(ME);
end

rawTable = table(rowVariant,rowRun,rowSeed,rowCostRaw,rowCostScaled,rowConv, ...
    rowDivProxy,rowArchiveSize,rowElapsed, ...
    'VariableNames', {'Configuration','Run','Seed','FinalBestCostRaw', ...
    'FinalBestCost_x1e3','ConvergenceIteration_1pct', ...
    'DiversityProxy_NOT_PublishedPDI','FinalArchiveSize','ElapsedSeconds'});
writetable(rawTable, fullfile(outputDir, 'Table10_RunLevel_Verification_Data.csv'));

nVariants = numel(variants);
summaryName = cell(nVariants,1);
meanCost = nan(nVariants,1); sdCost = nan(nVariants,1);
meanConv = nan(nVariants,1); sdConv = nan(nVariants,1);
meanDiv = nan(nVariants,1); sdDiv = nan(nVariants,1);
meanArchive = nan(nVariants,1);
for v = 1:nVariants
    idx = strcmp(rowVariant, variants(v).name);
    summaryName{v} = variants(v).name;
    meanCost(v) = mean(rowCostScaled(idx));
    sdCost(v) = std(rowCostScaled(idx), 0);
    meanConv(v) = mean(rowConv(idx));
    sdConv(v) = std(rowConv(idx), 0);
    meanDiv(v) = mean(rowDivProxy(idx));
    sdDiv(v) = std(rowDivProxy(idx), 0);
    meanArchive(v) = mean(rowArchiveSize(idx));
end
costChange = 100 * (meanCost - meanCost(1)) ./ max(abs(meanCost(1)), eps);
summaryTable = table(summaryName,meanCost,sdCost,meanConv,sdConv, ...
    meanDiv,sdDiv,meanArchive,costChange, ...
    'VariableNames', {'Configuration','MeanFinalBestCost_x1e3', ...
    'SD_FinalBestCost_x1e3','MeanConvergenceIteration_1pct', ...
    'SD_ConvergenceIteration','MeanDiversityProxy_NOT_PublishedPDI', ...
    'SD_DiversityProxy','MeanFinalArchiveSize','CostIncreaseVsFull_percent'});
writetable(summaryTable, fullfile(outputDir, ...
    'Table10_Verification_Summary_NOT_ORIGINAL.csv'));

save(fullfile(outputDir, 'Table10_AllRun_Metadata_and_Traces.mat'), ...
    'cfg','variants','runSummary','rawTable','summaryTable','-v7.3');

% Plot the average best-so-far convergence trace for each configuration.
fig = figure('Visible','off','Color','w');
ax = axes(fig); hold(ax,'on');
for v = 1:nVariants
    idx = strcmp({runSummary.variant}, variants(v).name);
    traceMatrix = nan(cfg.nRuns, cfg.MaxIt);
    selected = find(idx);
    for q = 1:numel(selected)
        tr = runSummary(selected(q)).bestCostTrace(:) ./ 1e3;
        traceMatrix(q,1:min(numel(tr),cfg.MaxIt)) = tr(1:min(numel(tr),cfg.MaxIt));
    end
    plot(ax, 1:cfg.MaxIt, mean(traceMatrix,1), 'LineWidth', 1.5);
end
xlabel(ax,'Iteration');
ylabel(ax,'Best-so-far weighted cost (x 10^3)');
legend(ax,{variants.name},'Interpreter','none','Location','best');
title(ax,'NEW verification runs: mean convergence profiles','Interpreter','none');
grid(ax,'on');
saveas(fig, fullfile(outputDir, 'Mean_Convergence_Profiles_NEW_VERIFICATION.png'));
close(fig);

% Save a text provenance note alongside the output.
fid = fopen(fullfile(outputDir,'README_Verification_Run.txt'),'w');
if fid < 0
    error('TAMOPSO:WriteMetadataFailed','Cannot write README_Verification_Run.txt.');
end
fprintf(fid,'NEW VERIFICATION EXPERIMENTS - NOT HISTORICAL RAW DATA\n');
fprintf(fid,'Created: %s\n', datestr(now,30));
fprintf(fid,'MATLAB version: %s\n', version);
fprintf(fid,'Computer: %s\n', computer);
fprintf(fid,'Runs/configuration: %d\nPopulation: %d\nIterations: %d\nArchive: %d\n', ...
    cfg.nRuns,cfg.nPop,cfg.MaxIt,cfg.nArchive);
fprintf(fid,'Base seed: %d (new verification seed series)\n', cfg.baseSeed);
fprintf(fid,'Convergence iteration definition: first best-so-far iteration within %.6g relative tolerance of final best-so-far cost.\n', ...
    cfg.convergenceRelativeTolerance);
fprintf(fid,'Diversity column is a nearest-neighbour diversity proxy, NOT the published PDI unless independently confirmed.\n');
fprintf(fid,'DTA uses rank terciles because the paper does not specify exact role cut-points.\n');
fprintf(fid,'ALM uses Mantegna Levy-flight sampling with parameters stored in each run file.\n');
fprintf(fid,'UCI uses exponential-distance archive pruning on scaled objective vectors.\n');
fprintf(fid,'Scalar cost is the supplied MyCost.m with component weights [5 1 10 1].\n');
fprintf(fid,'Confirm these methodological choices against the original research protocol before making claims of exact reproduction.\n');
fclose(fid);

fprintf('\nCompleted successfully. Results saved to:\n%s\n', outputDir);
fprintf('The summary explicitly labels the new diversity measure as a proxy.\n');
end
